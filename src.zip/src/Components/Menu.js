function Menu() {
  return (
    <div className="menu w-25  d-flex flex-column align-items-start">
      <p>Home</p>
      <p>Explore</p>
      <p>Notifications</p>
    </div>
  );
}

export default Menu;
