function Trends() {
  return <div className="w-25">Trends</div>;
}

export default Trends;
