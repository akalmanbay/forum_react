import ava from "../media/ava.jpeg";

let info = {
  name: "Akma",
  nickname: "aklmnb",
  time: "23h",
  content: "sokdfhijbhvdihcdv",
  media: "../media/ava.jpeg",
};

function Post() {
  return (
    <div className="post d-flex justify-content-start align-items-start w-100 bg-light my-3">
      <div
        class=" d-flex align-items-start justify-content-start m-1 "
        style={{ width: "10%" }}
      >
        <img
          src={ava}
          className="img-fluid m-1"
          style={{
            borderRadius: "100%",
            width: "100%",
            height: "100%",
            objectFit: "contain",
          }}
        />
      </div>

      <div className="content d-flex flex-column m-1" style={{ width: "80%" }}>
        <div class="d-flex">
          <div className="me-2">{info.name}</div>
          <div className="me-1">@{info.nickname}</div>
          <div className="me-1">*</div>
          <div>{info.time}</div>
        </div>
        <div>{info.content}</div>
        <div>Media</div>
        <div class="bottom d-flex w-50 justify-content-between">
          <btn class="btn">Like</btn>
          <btn class="btn">Comment</btn>
          <btn class="btn">Share</btn>
        </div>
      </div>
      <btn class="btn p-1" style={{ width: "10%" }}>
        X
      </btn>
    </div>
  );
}

function Feed() {
  return <Post />;
}

export default Feed;
