import "bootstrap/dist/css/bootstrap.min.css";
import "./App.css";
import Menu from "./Components/Menu";
import Trends from "./Components/Trends";
import Feed from "./Components/Feed";
import Tweet from "./Components/Tweet";

function App() {
  return (
    <div className="App d-flex mx-5 my-3 justify-content-center">
      <Menu />
      <div className="w-50 d-flex flex-column justify-content-center">
        <Tweet />
        <Feed />
      </div>
      <Trends />
    </div>
  );
}

export default App;
